---------------------------------------------------------------------- 
<Game> JoJo's Bizarre Adventure - The 7th Stand User
<Version> 2.45E Beta
<Type> Freeware
<Compatible Operating Systems> Windows 95/98/ME/2000/XP/Vista/7
<URL> http://tinyurl.com/7thstand
<Email> brandnewscooby@gmail.com
---------------------------------------------------------------------- 
*This is a freeware game made using RPG Maker 2000. Do NOT re-
distribute. We are not responsible for any damage to your computer 
that may occur as a result of downloading or playing unauthorized 
versions.
---------------------------------------------------------------------- 
Credits:

Concept & Development: NendoTairiku 
                       (http://clayman.net)
Music:                 Nihon Hakei by Kenji 
                       (http://nihonhakei.com/)
                       Maou Damashii 
                       (http://maoudamashii.jokersounds.com/)
                       MichiKougaku
                       (http://dooooooo.sitemix.jp/)
Pixel Artwork:         16dot
                       (http://r-mugendou.com/ura/item/)
English Translation:   Maud Duke
                       (http://7thjojo.tumblr.com/)

*Re-use of any of the game resources is strictly forbidden. If you'd
 like to use any of these files in your game, contact their respective
 creator(s) about obtaining a license.
---------------------------------------------------------------------- 
<FAQ>

-Technical Issues-

1. The font looks all squished!

   This game uses the MS Gothic font. If the font file isn't found on 
   the computer, it will cause the game text to look garbled. You can 
   download the font file here: (http://divinelegy.com/rmt/utilities/)

2. The music won't play!

   In Windows 7, simply right-click the speaker icon in the taskbar
   and click "Open Volume Mixer", then make sure that 7th Stand User 
   isn't muted as Skype and other programs have a nasty tendency of
   fiddling with it. In all other versions of Windows, go to Sound and 
   Audio Devices in the Control Panel and select Sound Playback under 
   the Audio tab. Click "Volume..." and increase the volume tab 
   labeled SW Synth. If you still aren't hearing music, see below.

3. The music is playing, but it's just the drum track/is off key!

   MIDI music isn't supported well in new versions of Windows. 
   CoolSoft's VirtualMIDISynth (http://tinyurl.com/3rqkw7r) should fix 
   the problem. If the default soundfont still has issues, then you 
   can download one a free one from the CoolSoft website.

   *Actually, even if your music plays fine, you may want to do this 
   anyway as the default MIDI instruments are very simplistic and can 
   be improved greatly by using a higher quality GM Soundfont. This 
   gameplay video (http://youtu.be/FuqEiYNP9uU) will give you an idea 
   of how the BGM sounds with the NTONYX 32MB Stereo Set, available
   here: (http://www.ntonyx.com/sf_f.htm)

4. I get a window saying "DirectDraw Error(DDERR_UNSUPPORTED)" 
   whenever I try to run the game!

   Some video cards don't like the way that RPG Maker handles full-
   screen mode. There's an easy step-by-step guide to fix this issue 
   here. (http://imgur.com/a/eJu3C) If that doesn't solve the problem, 
   you can always download RPG Maker 2000 (link not provided) and run 
   the game in test mode through the editor.

5. Is there a way to run the game on Mac?

   At present, the only way to play RPG Maker games on Mac is through 
   an emulator such as Parallels or Boot Camp.

6. What about Windows 8?

   I don't know a single person who has Windows 8 so it's anyone's 
   guess. Sorry.

7. Is there a way to disable fullscreen mode?

   Pressing F4 during gameplay will toggle windowed mode, and pressing
   F5 when in windowed mode will toggle the game's resolution between
   640x480 and 320x240.

8. The game is lagging!

   Running the game in Windowed mode and switching to 320x240
   resolutions using the above instructions in question 5 can help
   the game run smoother. Changing your display from True Color to 
   High Color/16-bit in the Control Panel can also help greatly.

9. My character is moving in random directions, and I'm not pressing
   any buttons!

   Unplug any joypads, external mice, or other peripherals and try 
   pressing one of the arrow keys on the keyboard or numpad. If you
   don't regain control of your character, restart your computer
   with all peripherals disconnected.

10. My saves vanished or crash on loading...

   RPG Maker 2000 has a rare bug where it will sometimes delete or 
   corrupt saves seemingly at random. As a result, it's highly 
   recommended that you periodically back up your saves (the files in 
   the game folder labeled Save0*.lsd) in a separate folder.

-Other Questions-

11. Can I play this game even if I haven't read all of JoJo's Bizarre 
   Adventure?

   This game is designed so that fans who haven't read past Stardust 
   Crusaders can enjoy it without fear of spoilers. Some characters 
   may make appearences, and there are some textual references to 
   later parts, but no significant plot points are revealed.

   As for people who haven't read JoJo's at all, reading Part 3 is 
   highly recommended, but not necessary - just be aware that as the 
   game follows the original story relatively closely, spoilers are a 
   given.

12. When does my nickname get used?

   Party members will start to use your nickname once they reach the
   required amount of Friendship Points (10). You can check Friendship
   Points using the radio.

13. (Anything not mentioned above)

   I am always working to make the English 7th Stand User experience
   better and am always available to contact about issues with the 
   game. You can get in touch with me at brandnewscooby@gmail.com.

----------------------------------------------------------------------
Copyright (C)2006-2014 NendoTairiku. All rights reserved.